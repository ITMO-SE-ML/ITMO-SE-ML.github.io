# Данные для учебного анализа

Источник: https://github.com/cristobalmitchell/pokedex
Версия: f6c9f3efc00a430fa06421f25c05c09380d9c623

pokemon.csv — таблица 1025 видов покемонов и их характеристик.
images64.npz — изображения на белом фоне, приведённые к 64×64 пикселям. Массив ids связывает изображения со столбцом national_number; rgb содержит цветные изображения, gray — полутоновые. Значения яркости от 0 до 1.

Исходная лицензия репозитория приведена в SOURCE_LICENSE. Права на персонажей и иллюстрации принадлежат их правообладателям.

Рукописные цифры загружаются из встроенного набора sklearn.datasets.load_digits: 1797 изображений 8×8, яркости 0–16. https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html
