"""Reproducible presentation-ready EDA for Palmer Penguins.

The script uses the local copy of the simplified ``penguins`` dataset from
the palmerpenguins R package and writes 16:9 PNG and vector PDF figures.

Run:
    python eda_penguins.py
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
import seaborn as sns


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "penguins.csv"
OUT = ROOT / "figures"
OUT.mkdir(parents=True, exist_ok=True)

# The lecture palette from main.tex.
PAPER = "#FAF9F6"
INK = "#202124"
MUTED = "#696A70"
RULE = "#D9D7D1"
GRID = "#E8E5DE"
COBALT = "#3159B8"
CORAL = "#D65443"
OCHRE = "#D59A2A"
SAGE = "#4E7B62"
SOFT_BLUE = "#E8EDF8"

SPECIES_ORDER = ["Adelie", "Chinstrap", "Gentoo"]
SPECIES_PALETTE = {
    "Adelie": COBALT,
    "Chinstrap": CORAL,
    "Gentoo": SAGE,
}
SEX_ORDER = ["female", "male"]
SEX_PALETTE = {"female": CORAL, "male": COBALT}


def configure_style() -> None:
    """Match the typography and palette used by the Beamer deck."""
    font_path = ROOT.parent.parent / "fonts" / "URWGothic-Book.otf"
    font_name = "DejaVu Sans"
    if font_path.exists():
        font_manager.fontManager.addfont(font_path)
        font_name = font_manager.FontProperties(fname=font_path).get_name()

    sns.set_theme(
        style="whitegrid",
        context="talk",
        font=font_name,
        rc={
            "figure.facecolor": PAPER,
            "savefig.facecolor": PAPER,
            "axes.facecolor": PAPER,
            "axes.edgecolor": RULE,
            "axes.labelcolor": INK,
            "axes.titlecolor": INK,
            "text.color": INK,
            "xtick.color": MUTED,
            "ytick.color": MUTED,
            "grid.color": GRID,
            "grid.linewidth": 0.8,
            "axes.titleweight": "bold",
            "axes.titlesize": 18,
            "axes.labelsize": 15,
            "xtick.labelsize": 12.5,
            "ytick.labelsize": 12.5,
            "legend.fontsize": 13,
        },
    )


def save(fig: plt.Figure, stem: str) -> None:
    """Save both slide-friendly raster and editable vector versions."""
    fig.savefig(OUT / f"{stem}.png", dpi=220, bbox_inches="tight", pad_inches=0.16)
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", pad_inches=0.16)
    plt.close(fig)


def clean_axis(ax: plt.Axes, *, grid_axis: str = "y") -> None:
    sns.despine(ax=ax)
    ax.grid(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8, zorder=0)


def structure_and_missingness(df: pd.DataFrame) -> None:
    """Dataset structure and the first data-quality issue: missing values."""
    fig, axes = plt.subplots(
        1,
        2,
        figsize=(12.8, 7.2),
        gridspec_kw={"width_ratios": [0.82, 1.42], "wspace": 0.34},
    )

    type_counts = pd.Series(
        {"Числовые измерения": 4, "Категориальные": 3, "Год наблюдения": 1}
    )
    colors = [COBALT, CORAL, OCHRE]
    bars = axes[0].barh(
        type_counts.index,
        type_counts.values,
        color=colors,
        height=0.56,
        zorder=3,
    )
    axes[0].invert_yaxis()
    axes[0].set_xlim(0, 4.75)
    axes[0].set_xlabel("Число признаков")
    axes[0].set_ylabel("")
    axes[0].set_title("344 наблюдения · 8 признаков", loc="left", pad=18)
    axes[0].set_xticks(range(0, 5))
    axes[0].bar_label(bars, padding=8, fontsize=16, fontweight="bold", color=INK)
    clean_axis(axes[0], grid_axis="x")

    missing = df.isna().sum().sort_values(ascending=True)
    labels = {
        "species": "Вид",
        "island": "Остров",
        "bill_length_mm": "Длина клюва",
        "bill_depth_mm": "Высота клюва",
        "flipper_length_mm": "Длина крыла",
        "body_mass_g": "Масса тела",
        "sex": "Пол",
        "year": "Год",
    }
    missing.index = [labels[column] for column in missing.index]
    missing_colors = [CORAL if value else RULE for value in missing.values]
    bars = axes[1].barh(
        missing.index,
        missing.values,
        color=missing_colors,
        height=0.58,
        zorder=3,
    )
    axes[1].set_xlim(0, 12.7)
    axes[1].set_xlabel("Число пропусков")
    axes[1].set_ylabel("")
    axes[1].set_title("Пропуски сосредоточены в поле «пол»", loc="left", pad=18)
    axes[1].set_xticks([0, 2, 4, 6, 8, 10, 12])
    axes[1].bar_label(bars, padding=7, fontsize=13.5, color=INK)
    clean_axis(axes[1], grid_axis="x")

    fig.subplots_adjust(left=0.10, right=0.98, top=0.86, bottom=0.15)
    save(fig, "01_structure_missingness")


def numeric_distributions(df: pd.DataFrame) -> None:
    """Compare the distributions of the four continuous measurements."""
    variables = [
        ("body_mass_g", "Масса тела, г"),
        ("flipper_length_mm", "Длина крыла, мм"),
        ("bill_length_mm", "Длина клюва, мм"),
        ("bill_depth_mm", "Высота клюва, мм"),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(12.8, 7.2))

    for ax, (column, label) in zip(axes.flat, variables):
        sns.histplot(
            data=df,
            x=column,
            hue="species",
            hue_order=SPECIES_ORDER,
            palette=SPECIES_PALETTE,
            bins=16,
            element="step",
            stat="density",
            common_norm=False,
            alpha=0.13,
            linewidth=2.2,
            legend=False,
            ax=ax,
        )
        ax.set_title(label, loc="left", pad=8)
        ax.set_xlabel("")
        ax.set_ylabel("Плотность")
        ax.tick_params(axis="y", labelleft=False)
        clean_axis(ax, grid_axis="x")

    handles = [Patch(facecolor=SPECIES_PALETTE[s], label=s) for s in SPECIES_ORDER]
    fig.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        ncol=3,
        frameon=False,
        title="Вид",
        title_fontsize=13,
        handlelength=1.2,
        columnspacing=1.8,
    )
    fig.subplots_adjust(left=0.08, right=0.98, top=0.86, bottom=0.09, wspace=0.18, hspace=0.36)
    save(fig, "02_numeric_distributions")


def categorical_structure(df: pd.DataFrame) -> None:
    """Show how categorical variables constrain the composition of the data."""
    fig, axes = plt.subplots(
        1,
        2,
        figsize=(12.8, 7.2),
        gridspec_kw={"width_ratios": [1.18, 1.0], "wspace": 0.34},
    )

    island_order = ["Biscoe", "Dream", "Torgersen"]
    island_species = pd.crosstab(df["island"], df["species"]).reindex(
        index=island_order, columns=SPECIES_ORDER, fill_value=0
    )
    bottoms = np.zeros(len(island_species))
    for species in SPECIES_ORDER:
        values = island_species[species].to_numpy()
        bars = axes[0].bar(
            island_species.index,
            values,
            bottom=bottoms,
            color=SPECIES_PALETTE[species],
            width=0.64,
            label=species,
            zorder=3,
        )
        for bar, value in zip(bars, values):
            if value >= 18:
                axes[0].text(
                    bar.get_x() + bar.get_width() / 2,
                    bar.get_y() + bar.get_height() / 2,
                    f"{int(value)}",
                    ha="center",
                    va="center",
                    fontsize=13,
                    fontweight="bold",
                    color="white",
                )
        bottoms += values
    axes[0].set_title("Виды распределены по островам неслучайно", loc="left", pad=18)
    axes[0].set_xlabel("Остров")
    axes[0].set_ylabel("Число наблюдений")
    axes[0].legend(title="Вид", frameon=False, ncol=1, loc="upper right")
    clean_axis(axes[0], grid_axis="y")

    complete_sex = df.dropna(subset=["sex"])
    sex_by_species = pd.crosstab(
        complete_sex["species"], complete_sex["sex"], normalize="index"
    ).reindex(index=SPECIES_ORDER, columns=SEX_ORDER)
    bottoms = np.zeros(len(sex_by_species))
    for sex in SEX_ORDER:
        values = sex_by_species[sex].to_numpy() * 100
        bars = axes[1].bar(
            sex_by_species.index,
            values,
            bottom=bottoms,
            color=SEX_PALETTE[sex],
            width=0.64,
            label={"female": "Самки", "male": "Самцы"}[sex],
            zorder=3,
        )
        for bar, value in zip(bars, values):
            axes[1].text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_y() + bar.get_height() / 2,
                f"{value:.0f}%",
                ha="center",
                va="center",
                fontsize=13,
                fontweight="bold",
                color="white",
            )
        bottoms += values
    axes[1].set_ylim(0, 100)
    axes[1].set_title("Среди размеченных объектов пол сбалансирован", loc="left", pad=18)
    axes[1].set_xlabel("Вид")
    axes[1].set_ylabel("Доля наблюдений")
    axes[1].set_yticks([0, 25, 50, 75, 100], labels=["0%", "25%", "50%", "75%", "100%"])
    axes[1].legend(frameon=False, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.0))
    clean_axis(axes[1], grid_axis="y")

    fig.subplots_adjust(left=0.08, right=0.98, top=0.84, bottom=0.14)
    save(fig, "03_categorical_structure")


def bill_relationship(df: pd.DataFrame) -> None:
    """Use a bivariate view to reveal species clusters and overlap."""
    complete = df.dropna(subset=["bill_length_mm", "bill_depth_mm"])
    fig, ax = plt.subplots(figsize=(12.8, 7.2))
    sns.scatterplot(
        data=complete,
        x="bill_length_mm",
        y="bill_depth_mm",
        hue="species",
        hue_order=SPECIES_ORDER,
        palette=SPECIES_PALETTE,
        s=78,
        alpha=0.76,
        edgecolor=PAPER,
        linewidth=0.8,
        legend=False,
        ax=ax,
    )

    # Direct labels avoid a small legend and keep the graphic readable on screen.
    label_offsets = {
        "Adelie": (-3.7, 0.8),
        "Chinstrap": (0.8, 0.55),
        "Gentoo": (1.0, -1.0),
    }
    centroids = complete.groupby("species", observed=True)[
        ["bill_length_mm", "bill_depth_mm"]
    ].median()
    for species in SPECIES_ORDER:
        x, y = centroids.loc[species]
        dx, dy = label_offsets[species]
        ax.annotate(
            species,
            xy=(x, y),
            xytext=(x + dx, y + dy),
            fontsize=15,
            fontweight="bold",
            color=SPECIES_PALETTE[species],
            bbox={"boxstyle": "round,pad=0.25", "facecolor": PAPER, "edgecolor": "none", "alpha": 0.92},
            arrowprops={"arrowstyle": "-", "color": SPECIES_PALETTE[species], "lw": 1.4},
        )

    ax.set_title("Два числовых признака уже разделяют виды", loc="left", pad=18)
    ax.set_xlabel("Длина клюва, мм")
    ax.set_ylabel("Высота клюва, мм")
    clean_axis(ax, grid_axis="both")
    fig.subplots_adjust(left=0.10, right=0.98, top=0.88, bottom=0.14)
    save(fig, "04_bill_relationship")


def body_mass_by_species_and_sex(df: pd.DataFrame) -> None:
    """Combine a numeric feature with two categorical variables."""
    complete = df.dropna(subset=["body_mass_g", "sex"])
    fig, ax = plt.subplots(figsize=(12.8, 7.2))
    sns.boxplot(
        data=complete,
        x="species",
        y="body_mass_g",
        order=SPECIES_ORDER,
        hue="sex",
        hue_order=SEX_ORDER,
        palette=SEX_PALETTE,
        width=0.64,
        linewidth=1.45,
        fliersize=0,
        ax=ax,
    )
    sns.stripplot(
        data=complete,
        x="species",
        y="body_mass_g",
        order=SPECIES_ORDER,
        hue="sex",
        hue_order=SEX_ORDER,
        dodge=True,
        palette={"female": INK, "male": INK},
        size=3.4,
        alpha=0.25,
        jitter=0.13,
        legend=False,
        ax=ax,
    )
    handles = [Patch(facecolor=SEX_PALETTE[s], label={"female": "Самки", "male": "Самцы"}[s]) for s in SEX_ORDER]
    ax.legend(handles=handles, title="Пол", frameon=False, ncol=2, loc="upper left")
    ax.set_title("Масса зависит и от вида, и от пола", loc="left", pad=18)
    ax.set_xlabel("Вид")
    ax.set_ylabel("Масса тела, г")
    ax.set_ylim(2500, 6500)
    clean_axis(ax, grid_axis="y")
    fig.subplots_adjust(left=0.10, right=0.98, top=0.88, bottom=0.14)
    save(fig, "05_body_mass_by_species_sex")


def write_summary(df: pd.DataFrame) -> None:
    numeric = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]
    summary = {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "numeric_measurements": len(numeric),
        "categorical_features": 3,
        "species": int(df["species"].nunique()),
        "islands": int(df["island"].nunique()),
        "missing_values_total": int(df.isna().sum().sum()),
        "missing_by_column": {key: int(value) for key, value in df.isna().sum().items()},
        "duplicate_rows": int(df.duplicated().sum()),
        "species_counts": {key: int(value) for key, value in df["species"].value_counts().items()},
    }
    (ROOT / "penguins_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def main() -> None:
    configure_style()
    df = pd.read_csv(DATA)
    df["species"] = pd.Categorical(df["species"], categories=SPECIES_ORDER, ordered=True)
    df["sex"] = pd.Categorical(df["sex"], categories=SEX_ORDER, ordered=True)

    structure_and_missingness(df)
    numeric_distributions(df)
    categorical_structure(df)
    bill_relationship(df)
    body_mass_by_species_and_sex(df)
    write_summary(df)

    print(f"Rows: {len(df)}; columns: {df.shape[1]}")
    print("Missing values:")
    print(df.isna().sum().to_string())
    print(f"Figures written to: {OUT}")


if __name__ == "__main__":
    main()
