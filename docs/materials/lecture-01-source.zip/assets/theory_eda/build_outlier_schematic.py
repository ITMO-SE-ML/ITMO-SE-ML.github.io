#!/usr/bin/env python3
"""Source-grounded schematic of three situations often called outliers.

Concepts are adapted from Google Machine Learning Crash Course, Numerical Data:
First Steps, and scikit-learn's anomaly-detection example on toy datasets.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from sklearn.datasets import make_blobs


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outlier_schematic.png"

INK = "#232326"
MUTED = "#707078"
COBALT = "#355fbd"
CORAL = "#d95343"
SAGE = "#55846a"
BG = "#fbfaf7"


def configure_style() -> None:
    font_path = ROOT.parent.parent / "fonts" / "URWGothic-Book.otf"
    if font_path.exists():
        font_manager.fontManager.addfont(font_path)
        family = font_manager.FontProperties(fname=font_path).get_name()
    else:
        family = "DejaVu Sans"
    plt.rcParams.update(
        {
            "font.family": family,
            "figure.facecolor": BG,
            "axes.facecolor": BG,
            "axes.edgecolor": "#d9d7d2",
            "axes.labelcolor": MUTED,
            "xtick.color": MUTED,
            "ytick.color": MUTED,
        }
    )


def finish_axis(ax: plt.Axes) -> None:
    ax.set_xticks([])
    ax.set_yticks([])
    for side in ("top", "right", "left", "bottom"):
        ax.spines[side].set_visible(False)
    ax.set_aspect("equal", adjustable="box")


def main() -> None:
    configure_style()
    rng = np.random.default_rng(12)

    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.25), constrained_layout=True)

    # Google MLCC: an outlier may be a data-entry or sensor mistake.
    core = rng.normal((0, 0), (0.50, 0.42), size=(120, 2))
    axes[0].scatter(core[:, 0], core[:, 1], s=18, color=COBALT, alpha=0.68)
    axes[0].scatter([2.75], [2.45], s=90, color=CORAL, marker="x", linewidth=3)
    axes[0].annotate(
        "ошибка?",
        (2.75, 2.45),
        xytext=(1.25, 2.8),
        color=CORAL,
        fontsize=14,
        arrowprops={"arrowstyle": "->", "color": CORAL, "lw": 1.6},
    )
    axes[0].set_title("Далеко от основной массы", fontsize=17, weight="bold", color=INK)
    axes[0].set_xlim(-2.0, 3.5)
    axes[0].set_ylim(-2.0, 3.35)
    finish_axis(axes[0])

    # Google MLCC: a legitimate rare group should not be deleted automatically.
    main_group = rng.normal((0, 0), (0.52, 0.44), size=(120, 2))
    rare_group = rng.normal((2.45, 1.9), (0.23, 0.20), size=(11, 2))
    axes[1].scatter(main_group[:, 0], main_group[:, 1], s=18, color=COBALT, alpha=0.66)
    axes[1].scatter(rare_group[:, 0], rare_group[:, 1], s=30, color=SAGE, alpha=0.92)
    axes[1].annotate(
        "редкая группа",
        rare_group.mean(axis=0),
        xytext=(0.55, 2.75),
        color=SAGE,
        fontsize=14,
        arrowprops={"arrowstyle": "->", "color": SAGE, "lw": 1.6},
    )
    axes[1].set_title("Редкое не значит ошибочное", fontsize=17, weight="bold", color=INK)
    axes[1].set_xlim(-2.0, 3.5)
    axes[1].set_ylim(-2.0, 3.35)
    finish_axis(axes[1])

    # scikit-learn toy anomaly example: inliers form one or two high-density modes;
    # uniform noise occupies low-density regions.
    modes, _ = make_blobs(
        n_samples=135,
        centers=[(-1.2, -0.4), (1.3, 0.8)],
        cluster_std=[0.48, 0.58],
        random_state=8,
    )
    noise = rng.uniform(low=(-2.7, -2.25), high=(2.8, 2.65), size=(18, 2))
    axes[2].scatter(modes[:, 0], modes[:, 1], s=18, color=COBALT, alpha=0.65)
    axes[2].scatter(noise[:, 0], noise[:, 1], s=34, color=CORAL, alpha=0.92)
    axes[2].set_title("Низкая локальная плотность", fontsize=17, weight="bold", color=INK)
    axes[2].set_xlim(-3.0, 3.1)
    axes[2].set_ylim(-2.55, 3.0)
    finish_axis(axes[2])

    fig.suptitle(
        "Сначала выясняем происхождение точки — только потом решаем, что с ней делать",
        fontsize=21,
        weight="bold",
        color=INK,
    )
    fig.savefig(OUT, dpi=220, bbox_inches="tight", facecolor=BG)
    print(OUT)


if __name__ == "__main__":
    main()
