"""Faithful, presentation-ready remake of the original Penguins EDA.

The original lecture used the seven-column seaborn-style Palmer Penguins
table.  The local CSV also contains ``year``; this script deliberately drops
that column so the schema and the plots match the user's 2025 slides.

Run from any directory:
    python eda_penguins_v2.py
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
import seaborn as sns


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "penguins.csv"
OUT = ROOT / "figures"
OUT.mkdir(parents=True, exist_ok=True)

PAPER = "#FAF9F6"
INK = "#202124"
MUTED = "#696A70"
RULE = "#D9D7D1"
GRID = "#E8E5DE"
COBALT = "#3159B8"
CORAL = "#D65443"
OCHRE = "#D59A2A"
SAGE = "#4E7B62"

SPECIES_ORDER = ["Adelie", "Chinstrap", "Gentoo"]
SPECIES_PALETTE = {
    "Adelie": COBALT,
    "Chinstrap": CORAL,
    "Gentoo": SAGE,
}

NUMERIC_COLUMNS = [
    "bill_length_mm",
    "bill_depth_mm",
    "flipper_length_mm",
    "body_mass_g",
]


def configure_style() -> None:
    """Use the same rounded sans-serif typeface and palette as the deck."""
    candidates = [
        ROOT.parent.parent / "fonts" / "URWGothic-Book.otf",
        ROOT.parent.parent / "fonts" / "URWGothic-Demi.otf",
    ]
    font_name = "DejaVu Sans"
    for font_path in candidates:
        if font_path.exists():
            font_manager.fontManager.addfont(font_path)
            font_name = font_manager.FontProperties(fname=font_path).get_name()
            break

    sns.set_theme(
        style="whitegrid",
        context="talk",
        font=font_name,
        rc={
            "figure.facecolor": PAPER,
            "savefig.facecolor": PAPER,
            "axes.facecolor": PAPER,
            "axes.edgecolor": RULE,
            "axes.labelcolor": INK,
            "axes.titlecolor": INK,
            "text.color": INK,
            "xtick.color": MUTED,
            "ytick.color": MUTED,
            "grid.color": GRID,
            "grid.linewidth": 0.8,
            "axes.titleweight": "bold",
            "axes.titlesize": 19,
            "axes.labelsize": 15,
            "xtick.labelsize": 12.5,
            "ytick.labelsize": 12.5,
        },
    )


def load_original_schema() -> pd.DataFrame:
    """Match the seven columns shown in the user's original lecture."""
    df = pd.read_csv(DATA)
    return df.drop(columns=["year"], errors="ignore")


def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.png", dpi=220, bbox_inches="tight", pad_inches=0.16)
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", pad_inches=0.16)
    plt.close(fig)


def clean_axis(ax: plt.Axes, *, grid_axis: str = "y") -> None:
    sns.despine(ax=ax)
    ax.grid(False)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8, zorder=0)


def dataset_preview(df: pd.DataFrame) -> None:
    """Rebuild the first Penguins slide: actual rows plus an explicit audit."""
    preview = df.dropna(subset=NUMERIC_COLUMNS).copy()
    preview["sex"] = preview["sex"].fillna("Unknown")
    preview = preview.head(7)
    preview = preview.rename(
        columns={
            "species": "species",
            "island": "island",
            "bill_length_mm": "bill length",
            "bill_depth_mm": "bill depth",
            "flipper_length_mm": "flipper",
            "body_mass_g": "mass",
            "sex": "sex",
        }
    )

    formatted = preview.copy()
    for column in ["bill length", "bill depth"]:
        formatted[column] = formatted[column].map(lambda value: f"{value:.1f}")
    formatted["flipper"] = formatted["flipper"].map(lambda value: f"{value:.0f}")
    formatted["mass"] = formatted["mass"].map(lambda value: f"{value:.0f}")

    fig, (ax_table, ax_audit) = plt.subplots(
        1,
        2,
        figsize=(12.8, 7.2),
        gridspec_kw={"width_ratios": [1.95, 0.8], "wspace": 0.08},
    )
    ax_table.axis("off")
    ax_audit.axis("off")

    table = ax_table.table(
        cellText=formatted.values,
        colLabels=formatted.columns,
        rowLabels=[str(index) for index in formatted.index],
        cellLoc="center",
        colLoc="center",
        bbox=[0.0, 0.08, 1.0, 0.82],
        colWidths=[0.13, 0.16, 0.16, 0.15, 0.14, 0.13, 0.13],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(11.2)
    table.scale(1, 1.34)
    for (row, column), cell in table.get_celld().items():
        cell.set_edgecolor(RULE)
        cell.set_linewidth(0.8)
        if row == 0:
            cell.set_facecolor(COBALT)
            cell.set_text_props(color="white", weight="bold")
        elif row % 2 == 0:
            cell.set_facecolor("#F0EFEA")
        else:
            cell.set_facecolor(PAPER)

    ax_table.set_title("Первые строки после минимальной очистки", loc="left", pad=16)

    ax_audit.text(0.02, 0.88, "344", fontsize=30, fontweight="bold", color=COBALT)
    ax_audit.text(0.02, 0.81, "наблюдения", fontsize=14, color=MUTED)
    ax_audit.text(0.02, 0.64, "7", fontsize=30, fontweight="bold", color=CORAL)
    ax_audit.text(0.02, 0.57, "признаков", fontsize=14, color=MUTED)
    ax_audit.text(0.02, 0.40, "19", fontsize=30, fontweight="bold", color=OCHRE)
    ax_audit.text(0.02, 0.33, "пропущенных значений", fontsize=14, color=MUTED)
    ax_audit.text(0.02, 0.16, "3", fontsize=30, fontweight="bold", color=SAGE)
    ax_audit.text(0.02, 0.09, "категориальных признака", fontsize=14, color=MUTED)

    fig.subplots_adjust(left=0.04, right=0.98, top=0.88, bottom=0.07)
    save(fig, "01_dataset_preview")


def original_numeric_distributions(df: pd.DataFrame) -> None:
    """Faithfully remake the two numeric distributions from slide 30."""
    variables = [
        ("flipper_length_mm", "Длина крыла, мм", COBALT),
        ("body_mass_g", "Масса тела, г", CORAL),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(12.8, 7.2), gridspec_kw={"wspace": 0.18})

    for ax, (column, title, color) in zip(axes, variables):
        values = df[column].dropna()
        sns.histplot(
            values,
            bins=18,
            stat="density",
            color=color,
            alpha=0.19,
            edgecolor=color,
            linewidth=1.0,
            ax=ax,
        )
        sns.kdeplot(values, color=color, linewidth=3.0, bw_adjust=0.8, ax=ax)
        median = values.median()
        ax.axvline(median, color=INK, linestyle=(0, (4, 4)), linewidth=1.6)
        ax.text(
            median,
            ax.get_ylim()[1] * 0.96,
            f"медиана {median:,.0f}".replace(",", " "),
            ha="center",
            va="top",
            fontsize=12.5,
            color=INK,
            bbox={"facecolor": PAPER, "edgecolor": "none", "pad": 2.5, "alpha": 0.92},
        )
        ax.set_title(title, loc="left", pad=16)
        ax.set_xlabel("")
        ax.set_ylabel("Плотность")
        ax.tick_params(axis="y", labelleft=False)
        clean_axis(ax, grid_axis="x")

    fig.suptitle(
        "Смешение видов делает одномерные распределения многомодальными",
        x=0.06,
        y=0.99,
        ha="left",
        fontsize=22,
        fontweight="bold",
    )
    fig.subplots_adjust(left=0.06, right=0.98, top=0.84, bottom=0.13)
    save(fig, "02_original_numeric_distributions")


def original_species_composition(df: pd.DataFrame) -> None:
    """Replace the original bar + pie pair without losing its information."""
    counts = df["species"].value_counts().reindex(SPECIES_ORDER)
    shares = counts / counts.sum() * 100

    fig, (ax_count, ax_share) = plt.subplots(
        1,
        2,
        figsize=(12.8, 7.2),
        gridspec_kw={"width_ratios": [1.25, 1.0], "wspace": 0.28},
    )

    colors = [SPECIES_PALETTE[species] for species in SPECIES_ORDER]
    bars = ax_count.bar(SPECIES_ORDER, counts.values, color=colors, width=0.62, zorder=3)
    ax_count.bar_label(
        bars,
        labels=[f"{count}\n({share:.1f}%)" for count, share in zip(counts, shares)],
        padding=8,
        fontsize=14,
        fontweight="bold",
        color=INK,
    )
    ax_count.set_ylim(0, 180)
    ax_count.set_title("Число наблюдений по видам", loc="left", pad=16)
    ax_count.set_xlabel("Вид")
    ax_count.set_ylabel("Число наблюдений")
    clean_axis(ax_count, grid_axis="y")

    left = 0.0
    for species, share, color in zip(SPECIES_ORDER, shares, colors):
        ax_share.barh([0], [share], left=left, height=0.34, color=color, zorder=3)
        ax_share.text(
            left + share / 2,
            0,
            f"{species}\n{share:.1f}%",
            ha="center",
            va="center",
            color="white",
            fontsize=14,
            fontweight="bold",
        )
        left += share
    ax_share.set_xlim(0, 100)
    ax_share.set_ylim(-0.65, 0.65)
    ax_share.set_yticks([])
    ax_share.set_xticks([0, 25, 50, 75, 100], labels=["0%", "25%", "50%", "75%", "100%"])
    ax_share.set_title("Доли видов", loc="left", pad=16)
    ax_share.set_xlabel("Доля датасета")
    clean_axis(ax_share, grid_axis="x")

    fig.suptitle(
        "Виды представлены неравномерно",
        x=0.06,
        y=0.99,
        ha="left",
        fontsize=22,
        fontweight="bold",
    )
    fig.subplots_adjust(left=0.07, right=0.98, top=0.83, bottom=0.14)
    save(fig, "03_original_species_composition")


def missingness_patterns(df: pd.DataFrame) -> None:
    """Show both missing counts and the two incomplete-row patterns."""
    missing = df.isna().sum().sort_values(ascending=True)
    labels = {
        "species": "Вид",
        "island": "Остров",
        "bill_length_mm": "Длина клюва",
        "bill_depth_mm": "Высота клюва",
        "flipper_length_mm": "Длина крыла",
        "body_mass_g": "Масса тела",
        "sex": "Пол",
    }

    fig, (ax_count, ax_pattern) = plt.subplots(
        1,
        2,
        figsize=(12.8, 7.2),
        gridspec_kw={"width_ratios": [1.2, 1.0], "wspace": 0.28},
    )

    missing.index = [labels[column] for column in missing.index]
    bars = ax_count.barh(
        missing.index,
        missing.values,
        color=[CORAL if value else RULE for value in missing.values],
        height=0.56,
        zorder=3,
    )
    ax_count.bar_label(bars, padding=7, fontsize=13.5, color=INK)
    ax_count.set_xlim(0, 12.5)
    ax_count.set_title("Сколько значений пропущено", loc="left", pad=16)
    ax_count.set_xlabel("Число пропусков")
    ax_count.set_ylabel("")
    clean_axis(ax_count, grid_axis="x")

    full_numeric_missing = df[NUMERIC_COLUMNS].isna().all(axis=1)
    only_sex_missing = df["sex"].isna() & ~full_numeric_missing
    complete = ~df.isna().any(axis=1)
    pattern_counts = pd.Series(
        {
            "Полностью заполнены": int(complete.sum()),
            "Нет только пола": int(only_sex_missing.sum()),
            "Нет измерений и пола": int(full_numeric_missing.sum()),
        }
    )
    colors = [COBALT, OCHRE, CORAL]
    bars = ax_pattern.barh(
        pattern_counts.index[::-1],
        pattern_counts.values[::-1],
        color=colors[::-1],
        height=0.54,
        zorder=3,
    )
    ax_pattern.bar_label(bars, padding=7, fontsize=14, fontweight="bold", color=INK)
    ax_pattern.set_xlim(0, 365)
    ax_pattern.set_title("Как выглядят неполные строки", loc="left", pad=16)
    ax_pattern.set_xlabel("Число строк")
    ax_pattern.set_ylabel("")
    clean_axis(ax_pattern, grid_axis="x")

    fig.suptitle(
        "Важно анализировать не только количество, но и структуру пропусков",
        x=0.06,
        y=0.99,
        ha="left",
        fontsize=22,
        fontweight="bold",
    )
    fig.subplots_adjust(left=0.10, right=0.98, top=0.83, bottom=0.14)
    save(fig, "04_missingness_patterns")


def write_summary(df: pd.DataFrame) -> None:
    counts = df["species"].value_counts().reindex(SPECIES_ORDER)
    summary = {
        "schema_source": "seven-column seaborn-style table used in lecture 1 (2025)",
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "missing_total": int(df.isna().sum().sum()),
        "missing_by_column": {key: int(value) for key, value in df.isna().sum().items()},
        "species_counts": {key: int(value) for key, value in counts.items()},
        "species_shares_percent": {
            key: round(float(value / counts.sum() * 100), 1) for key, value in counts.items()
        },
    }
    (ROOT / "penguins_v2_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def main() -> None:
    configure_style()
    df = load_original_schema()
    dataset_preview(df)
    original_numeric_distributions(df)
    original_species_composition(df)
    missingness_patterns(df)
    write_summary(df)
    print(f"Rows: {len(df)}; columns: {df.shape[1]}")
    print(df.isna().sum().to_string())
    print(f"Figures written to: {OUT}")


if __name__ == "__main__":
    main()
